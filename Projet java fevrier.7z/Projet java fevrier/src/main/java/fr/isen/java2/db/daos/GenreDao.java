package fr.isen.java2.db.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import fr.isen.java2.db.entities.Genre;

public class GenreDao {

    // Méthode pour récupérer la liste des genres
    public List<Genre> listGenres() {
        List<Genre> genres = new ArrayList<>();
        try (Connection connection = DataSourceFactory.getDataSource().getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM genre");
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                int id = resultSet.getInt("idgenre");
                String name = resultSet.getString("name");
                Genre genre = new Genre(id, name);
                genres.add(genre);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return genres;
    }

    // Méthode pour récupérer un genre par son nom
    public Genre getGenre(String name) {
        Genre genre = null;
        try (Connection connection = DataSourceFactory.getDataSource().getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM genre WHERE name = ?");
        ) {
            statement.setString(1, name);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    int id = resultSet.getInt("idgenre");
                    genre = new Genre(id, name);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return genre;
    }

    // Méthode pour ajouter un genre
    public void addGenre(String name) {
        try (Connection connection = DataSourceFactory.getDataSource().getConnection();
             PreparedStatement statement = connection.prepareStatement("INSERT INTO genre(name) VALUES(?)")) {
            statement.setString(1, name);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
